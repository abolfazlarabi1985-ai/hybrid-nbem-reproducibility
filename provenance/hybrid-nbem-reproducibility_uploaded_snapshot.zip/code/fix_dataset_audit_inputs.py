from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import List

import pandas as pd

CARDIO_COLUMNS: List[str] = [
    "LB", "AC", "FM", "UC", "DL", "DS", "DP", "ASTV", "MSTV",
    "ALTV", "MLTV", "Width", "Min", "Max", "Nmax", "Nzeros",
    "Mode", "Mean", "Median", "Variance", "Tendency", "CLASS", "NSP",
]


def norm(value: object) -> str:
    return "".join(ch for ch in str(value).strip().upper() if ch.isalnum())


def locate_single_csv(folder: Path) -> Path:
    files = sorted(folder.glob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No CSV file found in: {folder}")
    if len(files) == 1:
        return files[0]
    preferred = [p for p in files if p.stem.lower() == folder.name.lower()]
    return preferred[0] if preferred else max(files, key=lambda p: p.stat().st_size)


def backup_file(path: Path) -> Path:
    backup = path.with_suffix(path.suffix + ".before_audit_fix.bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    return backup


def repair_cardiotocography(project_root: Path) -> Path:
    folder = project_root / "datasets" / "processed" / "cardiotocography"
    csv_path = locate_single_csv(folder)
    raw = pd.read_csv(csv_path, header=None, dtype=object, low_memory=False)

    header_idx = None
    header_values = None
    for idx, row in raw.iterrows():
        values = [norm(v) for v in row.tolist()]
        value_set = set(values)
        if {"LB", "CLASS", "NSP"}.issubset(value_set):
            header_idx = int(idx)
            header_values = values
            break

    if header_idx is None or header_values is None:
        raise RuntimeError(
            "Could not locate the Cardiotocography header row containing LB, CLASS, and NSP. "
            "The original file was not modified."
        )

    positions = {}
    for name in CARDIO_COLUMNS:
        target = norm(name)
        matches = [i for i, value in enumerate(header_values) if value == target]
        if not matches:
            raise RuntimeError(f"Required Cardiotocography column was not found: {name}")
        positions[name] = matches[0]

    cleaned = raw.iloc[header_idx + 1 :, [positions[name] for name in CARDIO_COLUMNS]].copy()
    cleaned.columns = CARDIO_COLUMNS
    cleaned = cleaned.replace(r"^\s*$", pd.NA, regex=True)
    cleaned = cleaned.dropna(axis=0, how="all")
    cleaned = cleaned.dropna(subset=["NSP"])

    # Remove repeated header rows if present.
    cleaned = cleaned[cleaned["LB"].map(norm) != "LB"]
    cleaned = cleaned[cleaned["NSP"].map(norm) != "NSP"]

    # Keep only genuine target labels. The original CTG NSP target uses classes 1, 2, and 3.
    nsp_numeric = pd.to_numeric(cleaned["NSP"], errors="coerce")
    cleaned = cleaned[nsp_numeric.isin([1, 2, 3])].copy()
    cleaned["NSP"] = nsp_numeric[nsp_numeric.isin([1, 2, 3])].astype(int)

    if cleaned.empty:
        raise RuntimeError("The cleaned Cardiotocography table is empty; the original file was not modified.")

    backup = backup_file(csv_path)
    cleaned.to_csv(csv_path, index=False, encoding="utf-8-sig")
    print(f"Cardiotocography repaired: {csv_path}")
    print(f"Rows: {len(cleaned)}, columns: {len(cleaned.columns)}")
    print(f"Backup: {backup}")
    print(f"Columns: {cleaned.columns.tolist()}")
    print(f"NSP distribution: {cleaned['NSP'].value_counts().sort_index().to_dict()}")
    return csv_path


def update_config(config_path: Path) -> None:
    with config_path.open("r", encoding="utf-8") as f:
        config = json.load(f)

    overrides = config.setdefault("dataset_overrides", {})
    ilpd = overrides.setdefault("ilpd_indian_liver_patient_dataset", {})
    candidates = ilpd.setdefault("target_candidates", [])
    for value in ["Dataset", "dataset", "Selector", "selector", "class", "target", "label"]:
        if value not in candidates:
            candidates.append(value)

    cardio = overrides.setdefault("cardiotocography", {})
    cardio["target_candidates"] = ["NSP", "nsp", "fetal_health", "target"]
    cardio["alternative_target_candidates"] = [
        "CLASS", "class", "A", "B", "C", "D", "E", "AD", "DE", "LD", "FS", "SUSP"
    ]

    backup = backup_file(config_path)
    with config_path.open("w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
        f.write("\n")

    print(f"Configuration updated: {config_path}")
    print(f"Backup: {backup}")


def verify(project_root: Path, config_path: Path) -> None:
    cardio_path = locate_single_csv(project_root / "datasets" / "processed" / "cardiotocography")
    ilpd_path = locate_single_csv(project_root / "datasets" / "processed" / "ilpd_indian_liver_patient_dataset")

    cardio = pd.read_csv(cardio_path, nrows=5)
    ilpd = pd.read_csv(ilpd_path, nrows=5)

    missing_cardio = [c for c in CARDIO_COLUMNS if c not in cardio.columns]
    if missing_cardio:
        raise RuntimeError(f"Cardiotocography verification failed. Missing: {missing_cardio}")
    if "Dataset" not in ilpd.columns:
        raise RuntimeError("ILPD verification failed: Dataset column was not found.")

    with config_path.open("r", encoding="utf-8") as f:
        config = json.load(f)
    ilpd_candidates = config["dataset_overrides"]["ilpd_indian_liver_patient_dataset"]["target_candidates"]
    if "Dataset" not in ilpd_candidates:
        raise RuntimeError("Configuration verification failed: Dataset is not an ILPD target candidate.")

    print("Verification passed.")
    print(f"ILPD target column: Dataset; sample labels: {ilpd['Dataset'].dropna().unique().tolist()}")
    print("Cardiotocography target column: NSP; CLASS remains available only as an alternative label to be dropped.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Repair the two dataset-audit inputs reported by NBEM v3.")
    parser.add_argument("--project-root", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    args = parser.parse_args()

    project_root = args.project_root.resolve()
    config_path = args.config.resolve()

    repair_cardiotocography(project_root)
    update_config(config_path)
    verify(project_root, config_path)
    print("\nDone. Re-run the NBEM audit-only command now.")


if __name__ == "__main__":
    main()
