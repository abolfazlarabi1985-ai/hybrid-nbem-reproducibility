@echo off
setlocal
cd /d C:\inetpub\wwwroot\up\uni\mlm\NBEM_Project\hybrid-nbem-reproducibility
call .venv\Scripts\activate.bat
python code\verify_v4_output.py --output-dir "C:\inetpub\wwwroot\up\uni\mlm\NBEM_Project\results\final_article_run_v4"
pause
