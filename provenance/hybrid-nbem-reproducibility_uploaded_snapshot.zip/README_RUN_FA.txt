فایل‌های این بسته را داخل ریشه ریپازیتوری hybrid-nbem-reproducibility کپی کنید.

ترتیب اجرا:
1) run_audit_v4.bat
2) فقط در صورت موفقیت Audit، فایل run_full_v4.bat
3) پس از پایان کامل، فایل verify_output_v4.bat

خروجی نهایی:
C:\inetpub\wwwroot\up\uni\mlm\NBEM_Project\results\final_article_run_v4

دیتاست‌های اصلی دست‌کاری نمی‌شوند. پاک‌سازی فاصله و Tab فقط در حافظه انجام می‌شود.
اجرای v4 از cache و خروجی اجرای قبلی استفاده نمی‌کند، چون هم فایل کد/تنظیمات و هم پوشه خروجی تغییر کرده‌اند.
