@echo off
setlocal
cd /d C:\inetpub\wwwroot\up\uni\mlm\NBEM_Project\hybrid-nbem-reproducibility
call .venv\Scripts\activate.bat
python code\nbem_article_experiments_v4_final.py --project-root "C:\inetpub\wwwroot\up\uni\mlm\NBEM_Project" --config "C:\inetpub\wwwroot\up\uni\mlm\NBEM_Project\hybrid-nbem-reproducibility\config\dataset_config_v4_final.json" --output-dir "results\final_article_run_v4" --audit-only
pause
