# Corrected final rerun (v4)

This revision preserves the approved NBEM model implementations and changes only data hygiene and leakage-safe preprocessing required by the final audit.

1. Leading/trailing whitespace is stripped from textual cells in memory. This merges the erroneous `ckd` / `ckd\t` target labels without modifying the source CSV.
2. Identifier fields are explicitly removed from Chronic Kidney Disease (`id`), Cirrhosis (`ID`), E. coli (`sequence_name`), and Glass Identification (`id`).
3. Unseen categorical values receive reserved code `0`; known training categories use codes `1..K`.
4. Unseen Boolean values are mapped to the training-fold modal binary code, preserving the 0/1 input required by Bernoulli NB.
5. Missing Boolean/categorical values remain missing until fold-local imputation; they are no longer converted to the literal string `nan` before imputation.
6. Remaining high-cardinality identifier-like variables now stop the audit.
7. A separate output folder (`results/final_article_run_v4`) prevents mixing corrected and previous results.
