# راهنمای قرار دادن پروژه در GitHub و Zenodo

## ۱. قبل از انتشار

- فایل‌های کد، تنظیمات، Notebook، README، LICENSE و CITATION.cff را نگه دارید.
- پوشه‌های داده خام یا پردازش‌شده را فقط زمانی منتشر کنید که مجوز هر دیتاست اجازه دهد. در حالت پیش‌فرض `.gitignore` داده‌ها را حذف می‌کند.
- اطلاعات شخصی، مسیرهای محلی ویندوز، فایل‌های موقت، cache و خروجی‌های ناقص را حذف کنید.
- یک اجرای کامل و بدون خطا انجام دهید و فایل‌های `dataset_config_used.json`، `execution_environment.json` و `RUN_SUMMARY.txt` را همراه خروجی نهایی نگه دارید.

## ۲. ساخت مخزن GitHub

در GitHub یک repository خالی با نامی مانند `hybrid-nbem-reproducibility` بسازید. سپس در پوشه پروژه اجرا کنید:

```bash
git init
git add .
git commit -m "Initial reproducible release for the Hybrid NBEM study"
git branch -M main
git remote add origin https://github.com/abolfazlarabi1985-ai/hybrid-nbem-reproducibility.git
git push -u origin main
```

## ۳. چه خروجی‌هایی در GitHub قرار بگیرند؟

قرار دهید:

- `code/`
- `config/`
- `notebooks/`
- `docs/`
- `README.md`
- `requirements.txt` و `environment.yml`
- `LICENSE` و `CITATION.cff`
- سه شکل نهایی
- CSV و LaTeX جدول‌های نهایی
- `execution_environment.json`
- `dataset_audit.csv`
- `RUN_SUMMARY.txt`

بهتر است فایل‌های بسیار حجیم زیر در GitHub معمولی commit نشوند:

- cache
- خروجی‌های fold-level بسیار بزرگ
- دیتاست‌های حجیم

این فایل‌ها را می‌توان در GitHub Release یا Zenodo قرار داد.

## ۴. ساخت Release

پس از اطمینان از اجرای نهایی:

```bash
git tag -a v1.0.0 -m "Reproducible article release"
git push origin v1.0.0
```

در صفحه GitHub یک Release از tag نسخه ۱ بسازید و ZIP خروجی کامل را به آن پیوست کنید.

## ۵. دریافت DOI از Zenodo

1. با حساب GitHub وارد Zenodo شوید.
2. در بخش GitHub، مخزن را فعال کنید.
3. یک GitHub Release جدید بسازید.
4. Zenodo به‌صورت خودکار یک نسخه آرشیوی و DOI ایجاد می‌کند.
5. DOI را در README، CITATION.cff و بخش Data/Code Availability مقاله اضافه کنید.

## ۶. متن نهایی Data/Code Availability

پس از انتشار واقعی مخزن و DOI:

```text
Code, configuration files, and preprocessing scripts are available at
https://github.com/USERNAME/hybrid-nbem-reproducibility. The archived release
is available through Zenodo at https://doi.org/10.xxxx/zenodo.xxxxxxx.
```

قبل از ساخته‌شدن لینک واقعی، آدرس یا DOI ساختگی در مقاله ننویسید.
