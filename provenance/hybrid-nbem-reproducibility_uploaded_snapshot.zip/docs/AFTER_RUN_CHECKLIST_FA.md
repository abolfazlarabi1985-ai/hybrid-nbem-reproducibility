# چک‌لیست بعد از اجرای کامل

1. ابتدا `CRITICAL_ACTION_REQUIRED.txt` را بررسی کنید. اگر این فایل وجود دارد، از نتایج مقاله استفاده نکنید.
2. در `dataset_audit.csv` مطمئن شوید هدف Diabetes برابر `readmitted` است.
3. در همان فایل بررسی کنید هدف Productivity سه‌کلاسه شده و تعداد کلاس‌ها ۳ است.
4. در Cardiotocography بررسی کنید `NSP` یا `fetal_health` هدف است و `CLASS` به‌عنوان ویژگی وارد نشده است.
5. تعداد seedها را در `average_metrics_by_model_seed.csv` کنترل کنید؛ برای هر مدل باید پنج seed موجود باشد.
6. در `all_fold_results.csv` هیچ سطر `ERROR` برای مدل‌های اصلی باقی نماند.
7. مقادیر Weighted-F1 و Macro-F1 را از جدول‌های جدید وارد مقاله کنید؛ اعداد نسخه قبلی را مخلوط نکنید.
8. WNB را در جدول اصلی، جدول dataset-wise و رتبه‌بندی نگه دارید.
9. Figure 4 و Figure 5 را وارد مقاله نکنید؛ فقط جدول هزینه محاسباتی باقی بماند.
10. جمله محدودیت baselineهای مدرن و جمله محدودیت cross-fitting را بدون حذف وارد Discussion/Conclusion کنید.
